# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['cat_facts']

package_data = \
{'': ['*']}

install_requires = \
['requests>=2.31.0,<3.0.0']

setup_kwargs = {
    'name': 'cat-facts',
    'version': '1.0.1',
    'description': '',
    'long_description': '# Readme\n\nAn example repository to demonstrate the use of Poetry to create and manage custom libraries.\n',
    'author': 'Byron Collier',
    'author_email': 'collieb@confused.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
